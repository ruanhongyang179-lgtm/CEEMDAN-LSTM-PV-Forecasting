# CEEMDAN-LSTM 光伏超短期功率预测（虚拟电厂 VPP）— 轻量级可运行实现

本项目基于论文 **《Ultra-Short-Term Power Output Prediction for Distributed
Photovoltaic in Virtual Power Plants Using CEEMDAN-LSTM》**（JoVE，作者 Cong Zhang 等）
的完整方法，提供一套**可直接运行、零联网下载、仅依赖轻量库**的 Python 实现。

> 运行环境约束（用户要求）：Windows / 无 GPU / 无 CUDA / Python 3.10+ / 仅 `numpy`、
> `matplotlib`、`pillow`。论文原栈（PyTorch + PyEMD + scikit-learn，需 GPU/大数据）中的
> 重组件均以**纯 numpy 手写等价实现**替代，并在下文「简化说明」逐条给出理由。

---

## 1. 快速开始

```bash
# 1) 创建虚拟环境（可选但推荐，需 Python 3.10+）
python -m venv venv
venv\Scripts\activate        # Windows
#   或 macOS/Linux: source venv/bin/activate

# 2) 安装依赖（仅需三个轻量包）
pip install -r requirements.txt

# 3) 一键运行（自动生成合成数据并完成全流程）
python main.py
```

- **首次运行**会在 `data/` 下生成合成测试数据（`pv_power.csv` 与 `site_metadata.csv`），
  之后可直接替换为你自己的数据（见 §5）。
- 运行完成后，`results/` 下生成 4 张过程图 + `summary.json` 汇总指标。
- 单次运行总时长 **< 10 分钟**（本机实测：首轮含 CEEMDAN 分解约 **6–7 分钟**；分解结果按数据哈希落盘缓存，命中后重跑约 **5 分钟**）。

---

## 2. 目录结构

```
CEEMDAN_LSTM_VPP/
├── main.py                  # 一键运行入口（编排完整流水线）
├── config/
│   └── settings.py          # 全局超参数与「论文参数 → 项目参数」对照
├── requirements.txt         # 轻量依赖清单
├── README.md                # 本文件
├── push_to_github.py        # 可选：一键推送本仓库到 GitHub（不影响 main.py 运行）
├── .gitignore
├── data/                    # 测试数据目录（首次运行自动生成）
│   ├── pv_power.csv         # 各站点功率时序 (kW)
│   └── site_metadata.csv    # 各站点装机容量 (kWp)
├── src/                     # 核心代码（模块化，禁止单文件）
│   ├── utils.py             # 评估指标（RMSE/MAE/MAPE/PICP/PINAW/pinball）
│   ├── data_generator.py    # 合成多站点 PV 数据生成器
│   ├── decomposition.py     # CEEMDAN 分解 + 频率分量合并
│   ├── preprocessing.py     # 时序切分 / 滑窗 / 标准化 / 跨站点张量
│   └── model.py             # 共享权重多通道 LSTM + 通道注意力 + 分位数回归头
├── cache/                   # CEEMDAN 分解缓存（首次运行自动生成，用于加速重跑）
└── results/                 # 输出目录（图 + summary.json）
    ├── fig_input.png
    ├── fig_loss.png
    ├── fig_result.png
    ├── fig_corr.png
    └── summary.json
```

---

## 3. 论文方法 → 代码实现 逐条对应

| 论文环节（Protocol） | 论文原始实现 | 本项目实现（`src/`） | 说明 |
|---|---|---|---|
| 数据：分布式光伏多站功率 | 香港科大 60 站 / 3 年 / 5 分钟实测（Dryad, 需下载） | `data_generator.py` 合成等价数据（复现日曲线、天气、云团传播时延、噪声） | 体积可控、零下载；格式与真实数据一致（§5 可替换） |
| 分解：CEEMDAN (Eq.2–4) | PyEMD 库 | `decomposition.py` 纯 numpy 实现（Torres 2011 算法：集成 EMD 取均值） | 自实现三次样条（自然边界）与 Hilbert 变换（FFT），**不依赖 scipy** |
| 频率分组 (Eq.5–6) | 按 IMF 阶次固定分组 | `group_into_freq`：阶次 1–5 高 / 6–9 中 / ≥10 低 / 残差 → 4 类 | 满足完整重构约束（Eq.7）：原序列 = 高+中+低+残差 |
| 预处理 / 滑窗 (Eq.9–11) | 逐(站点,频率)标准化 + 滑窗张量 Z(t)∈R^{N×L×4} | `preprocessing.build_windows` | 仅用训练集统计标准化，避免信息泄漏 |
| 共享权重多通道 LSTM (Eq.12) | PyTorch `nn.LSTM`（各通道共享权重） | `model.MultiChannelLSTM` 纯 numpy 手写前向/反向（含 BPTT） | 数学验证：数值梯度校验通过（§6） |
| 通道注意力 (Eq.13–14) | 可学习 W_q/W_k 点积注意力 | 无参固定温度点积注意力（跨站点加权融合） | 保留「跨站点加权融合」结构，去掉可学习参数以稳训练（见简化说明） |
| 分位数回归头 (Eq.15) | 线性映射到 H 步 × 3 分位 | 解码器 `Yflat = fused @ Wd + bd` → (H, Q) | 输出 0.05/0.5/0.95 分位 |
| 损失：pinball (Eq.20–21) + L2 (Eq.23) | 分位数 pinball + 权重衰减 | `model.backward` 中 pinball 损失 + `WEIGHT_DECAY` | 点预测分支(MSE, λ=0.1)仅作评估，未并入训练目标以简化图 |
| 评估：RMSE/MAE/MAPE (Eq.24–26) + PICP/PINAW (Eq.27–28) | scikit-learn + 自实现 | `utils.py` 全部自实现 | MAPE 剔除聚合功率 < 总装机 5% 的时段 |
| VPP 聚合 | 各站预测求和得 VPP 总功率 | `main.predict_vpp` 反标准化后按站点求和 | 与持续性基线、无分解消融对比 |

---

## 4. 主要参数含义（`config/settings.py`）

| 参数 | 默认值 | 含义 |
|---|---|---|
| `N_SITES` | 8 | 站点数（论文 60，轻量实现取 8） |
| `N_DAYS` | 14 | 合成数据天数（论文约 1095 天） |
| `SAMPLE_INTERVAL_MIN` | 5 | 采样间隔（分钟），与论文一致 |
| `SEED` | 20241012 | 随机种子，保证可复现 |
| `INPUT_STEPS` (L) | 12 | 历史输入窗口步数（=60 分钟） |
| `HORIZON` (H) | 24 | 预测步长（=120 分钟，多步超前预测） |
| `QUANTILES` | [0.05,0.5,0.95] | 输出分位数（点预测 + 90% 区间） |
| `CEEMDAN_NOISE_AMP` | 0.2 | 白噪声幅值系数（相对原序列标准差） |
| `CEEMDAN_ENSEMBLE` | 3 | 集成次数（论文 100，轻量取 3） |
| `CEEMDAN_MAX_IMF` | 12 | 最大 IMF 层数 |
| `CEEMDAN_SD_TOL` | 0.2 | 筛分停止准则阈值 |
| `FREQ_GROUP_HIGH/MID/LOW` | 1–5 / 6–9 / 10–12 | 频率分组 IMF 阶次 |
| `N_FREQ` | 4 | 合并后频率分量数（高/中/低/残差） |
| `LSTM_HIDDEN` | 20 | LSTM 隐藏维度（论文 64，轻量取 20，兼顾精度与 10 分钟预算） |
| `LEARNING_RATE` | 3e-3 | Adam 学习率（较论文的 1e-3 上调，避免小样本下的欠拟合） |
| `BATCH_SIZE` | 64 | 批量大小 |
| `MAX_EPOCHS` | 20 | 最大训练轮数（论文 200，轻量取 20，配合早停） |
| `EARLY_STOP_PATIENCE` | 5 | 验证损失连续不下降即早停 |
| `WEIGHT_DECAY` | 1e-4 | L2 正则系数 |
| `SPLIT_TRAIN` / `SPLIT_VAL` | 0.7 / 0.15 | 按时间顺序的 训练/验证/测试 切分（测试=剩余 0.15） |
| `VPP_CAPACITY_KWP` | 2230.8 | VPP 总装机(kWp)，仅用于 PINAW 归一化（真实数据用此值；合成数据自动用各站容量之和） |
| `MAPE_LOW_POWER_RATIO` | 0.05 | MAPE 剔除聚合功率 < 总装机 5% 的时段 |
| `NOMINAL_COVERAGE` | 0.95 | 名义区间覆盖率（90% 区间对应 0.95 名义覆盖） |
| `FIG_DPI` | 120 | 输出图片分辨率 |
| `SHOW_PLOTS` | False | 无界面环境设 False，仅保存图片 |

> 修改参数：直接编辑 `config/settings.py` 后重跑 `python main.py` 即可。

---

## 5. 如何替换为你自己的数据

`main.py` 首次运行生成以下两个文件（在 `data/` 下），**保持相同格式即可直接替换**：

### `data/pv_power.csv`
- 第一列：`timestamp`，格式 `YYYY-MM-DD HH:MM:SS`（可解析即可）。
- 其余各列：各站点功率，列名任意（建议 `site_1, site_2, ...`），单位 **kW**。
- 维度：`(T, 1+N)`，T 为时间步数，N 为站点数。

```csv
timestamp,site_1,site_2,site_3
2023-01-01 00:00:00,0.0,0.0,0.0
2023-01-01 00:05:00,0.0,0.0,0.0
...
```

### `data/site_metadata.csv`
- 列：`site_id, capacity_kwp[, x_position]`。
- `capacity_kwp`：该站点装机容量(kWp)，用于 VPP 容量与 PINAW 归一化；缺失时自动用峰值功率×1.05 估计。
- `x_position`（可选）：站点地理位置，用于跨站点时滞分析。

```csv
site_id,capacity_kwp,x_position
site_1,45.0,0.0
site_2,52.0,1.0
...
```

替换后**删除旧的 `data/pv_power.csv`/`site_metadata.csv` 之外的缓存**并直接运行 `python main.py`；
若文件已存在，`ensure_data()` 会直接加载你的数据（除非删除或设 `exist_ok=False`）。

> 注意：你的数据建议同样为 **5 分钟采样**；若采样间隔不同，请同步修改 `SAMPLE_INTERVAL_MIN`。
> 若实测为 1 年/3 年数据，可增大 `N_DAYS` 无关、直接把整段喂入（流程按时间切分）。

---

## 6. 训练正确性验证

`src/model.py` 内含**数值梯度校验**（`python -m src.model` 或作为脚本运行）：
对小型随机输入，将解析梯度与中心差分数值梯度逐项比对。手写的 LSTM BPTT、
通道注意力反向、分位数解码器反向均通过校验（相对误差 ~1e-8）。

> 校验采用光滑 MSE 损失（pinball 为分段线性，近零梯度方向有限差分不稳），
> 用于验证整张反向计算图（LSTM/注意力/解码器 Jacobian）的正确性；训练仍使用 pinball 损失。

---

## 7. 简化说明（为什么这样做）

| 简化项 | 原因 |
|---|---|
| PyTorch → 纯 numpy 手写 LSTM + BPTT | 无 GPU/CUDA 环境无法跑 PyTorch；手写前向/反向并已通过数值梯度校验，保证正确性 |
| PyEMD → 自实现 CEEMDAN | PyEMD 为额外重依赖；CEEMDAN 算法（Torres 2011）可纯 numpy 复现，重构误差 ~1e-16 |
| scipy → 自实现三次样条 + Hilbert(FFT) | 去除 scipy 依赖，使项目仅靠 `numpy/matplotlib/pillow` 即可运行，安装最轻 |
| 真实大数据集 → 合成数据 | 真实数据需联网下载且体量大；合成数据刻意复现论文依赖的关键物理现象（日曲线、天气、云团传播时延、测量噪声） |
| 站点 60→8、IMF 集成 100→3、隐藏 64→20、epoch 200→20 | 控制单次运行在 10 分钟内，同时保持方法语义一致（多步超前预测、频率分解、通道注意力）；隐藏维度与轮数经性能剖析后定标（`B·N·K` 通道数会使 numpy 矩阵乘进入内存带宽瓶颈，隐藏维度取 20 是精度/耗时折中） |
| 学习率 1e-3→3e-3 | 小样本合成数据下，论文的 1e-3 在本轻量实现中收敛过慢导致明显欠拟合；上调至 3e-3 后验证损失快速下降，模型显著超过持续性基线 |
| 可学习注意力 W_q/W_k → 固定温度无参注意力 | 保留「跨站点加权融合」核心结构，同时避免轻量手写实现下可学习注意力带来的训练不稳定；消融实验用于验证分解增益 |
| 点预测 MSE 分支(λ=0.1) 仅作评估 | 训练目标仅用分位数 pinball + L2；点预测指标单独计算，保持训练图简洁稳健 |
| 训练损失曲线 = 各 batch 平均 pinball，验证损失仅对验证集前向一次/轮 | 全量训练集（B·N·K≈9 万通道）每轮额外前向一次需数十秒，整个训练即超预算；改为「batch 均值」记训练曲线、每轮仅对验证集前向一次 |
| CEEMDAN 分解结果缓存（`cache/`） | CEEMDAN 分解确定且耗时（约占整个流程的 1/3）。按「数据文件哈希 + 分解相关配置」做缓存键，命中则直接加载，重跑显著提速；替换 `data/` 后缓存自动失效重算。删除 `cache/` 不影响正确性（只是变慢） |

---

## 8. 输出解读（`results/summary.json`）

`summary.json` 汇总：配置快照、数据规模、各站点 IMF 数量、训练轮数/损失、
以及三类模型在 **VPP 总功率**上的指标：

- `full_model_CEEMDAN_LSTM`：完整方法（CEEMDAN + 多通道 LSTM + 注意力 + 分位数）。
- `persistence_baseline`：持续性基线（以输入末步功率外推）。
- `ablation_no_decomposition`：消融——直接对原始功率建模（无 CEEMDAN）。

本机内置合成数据、默认配置下的实测结果（VPP 总功率，RMSE/MAE 单位 kW）：

| 模型 | RMSE | MAE | MAPE(%) |
|---|---|---|---|
| full_model_CEEMDAN_LSTM | 16.76 | 11.23 | 13.47 |
| persistence_baseline | 41.36 | 25.77 | 42.88 |
| ablation_no_decomposition | 14.97 | 7.56 | 13.21 |

**结论解读（如实说明，便于你判断）：**

1. 完整数据驱动方法相对**持续性基线大幅领先**（RMSE 降低约 **59%**），验证了「多通道 LSTM +
   分位数回归」对超短期光伏预测的有效性——这是本实现最稳健、最显著的结论。
2. 但在**本合成数据**上，「无分解」消融与完整模型相当、甚至略优（14.97 vs 16.76）。原因：
   合成数据的频率分量以**残差（趋势）为主**（约占功率方差 100%），高频分量接近噪声，
   此设置下 CEEMDAN 分解未带来净增益。论文所用的真实分布式光伏（60 站 / 3 年 / 5 分钟实测）
   中各 IMF 含更丰富的可学习结构（云团与天气过程），分解增益通常更明显。
   **该差异属数据集特性，并非实现缺陷**——你可替换为真实数据（§5）后复现论文式对比。
3. 若希望放大分解增益，可优先调整数据生成中的**云团动力学**（`src/data_generator.py` 中
   `n_blobs`、速度与强度）与**测量噪声幅值**，使高频分量含更多可学习结构。

指标含义：**RMSE/MAE** 越低越好；**MAPE** 越低越好（已剔除低功率时段）；
**PICP** 越接近 `NOMINAL_COVERAGE`(0.95) 越好；**PINAW** 越小表示区间越窄且仍覆盖。

四张图：`fig_input.png`（输入与分解可视化）、`fig_loss.png`（训练/验证损失收敛）、
`fig_result.png`（VPP 预测 vs 实际 + 90% 区间）、`fig_corr.png`（跨站点相关性与云团传播时滞）。

---

## 9. 上传到 GitHub（可选）

项目已带 `.git` 仓库（分支 `main`，全部文件已提交），并提供 `push_to_github.py`。
本机无 GitHub 凭据，推送需你提供一次写入凭据：

```bash
# 1) 设置 Token（GitHub → Settings → Developer settings → Personal access tokens）
export GITHUB_TOKEN=你的token        # Windows CMD 用 set GITHUB_TOKEN=...

# 2) 若仓库你已在网页手动建好（推荐先建好空仓库）
python push_to_github.py --no-create

#    或让脚本自动创建（公开仓库；加 --private 则建私有）
python push_to_github.py
```

`push_to_github.py` 只用标准库，流程为「创建仓库 → 关联 origin → 推送 `main` → 抹掉 URL 中的 token」，
推送结束后 `.git/config` 不残留凭据。若你只想手动推送：

```bash
git branch -M main
git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git push -u origin main            # 会弹出 GitHub 登录窗口，登录后自动完成
```
