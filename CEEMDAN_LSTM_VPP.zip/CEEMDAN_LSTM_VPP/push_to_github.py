#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把本项目一键推送到 GitHub（可选工具，与 main.py 的运行完全无关，删掉也不影响复现）。

为什么需要它：本机没有 gh CLI、没有 SSH key、也没有保存任何 GitHub 凭据，
所以推送必须由你提供一次写入凭据（Personal Access Token）。本脚本负责
「创建仓库 → 关联远端 → 推送 → 抹掉凭据」，全部用标准库，无第三方依赖。

--------------------------------------------------------------------------
用法
--------------------------------------------------------------------------
1) 先在 GitHub 生成一个 Token（二选一）：

   A. 经典 Token（最简单）
      https://github.com/settings/tokens/new
      勾选 scope:  repo （整块勾上即可）
   B. 细粒度 Token（更安全）
      https://github.com/settings/personal-access-tokens/new
      勾选：
        - Repository access: All repositories（或只选你要推的那个）
        - Permissions → Repository permissions → Contents: Read and write
        - （若让脚本自动建仓库，还需）Administration: Read and write

2) 把 Token 放进环境变量（不要写进代码、不要提交到仓库）：

   Git Bash / WSL  :  export GITHUB_TOKEN=ghp_xxxxxxxx
   Windows CMD     :  set GITHUB_TOKEN=ghp_xxxxxxxx
   PowerShell      :  $env:GITHUB_TOKEN="ghp_xxxxxxxx"

3) 运行（在项目根目录下）：

   # 自动创建「公开」仓库并推送
   python push_to_github.py

   # 自动创建「私有」仓库并推送
   python push_to_github.py --private

   # 你已经手动在网页建好了仓库 → 跳过创建，直接推
   python push_to_github.py --no-create

   # 换个仓库名
   python push_to_github.py --repo 我的仓库名

推送成功后，脚本会把 origin 还原成不含 token 的地址，
所以 .git/config 里不会残留凭据。
--------------------------------------------------------------------------
"""

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

API = "https://api.github.com"
DEFAULT_REPO = "CEEMDAN-LSTM-PV-Forecasting"
DEFAULT_DESC = ("CEEMDAN-LSTM 分布式光伏超短期功率预测（虚拟电厂 VPP）"
                "——纯 numpy 轻量复现，无 PyTorch/PyEMD/scipy 依赖")


def api(method, path, token, payload=None):
    """调用 GitHub REST API，返回解析后的 JSON。"""
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(API + path, data=body, method=method)
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "ceemdan-lstm-push-script")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw) if raw.strip() else {}


def git(args, **kw):
    print("   $ git " + " ".join(a if "x-access-token" not in a else "<remote>" for a in args))
    return subprocess.run(["git"] + args, check=True, **kw)


def main():
    ap = argparse.ArgumentParser(description="一键把本项目推送到 GitHub")
    ap.add_argument("--repo", default=DEFAULT_REPO, help="仓库名（默认 %s）" % DEFAULT_REPO)
    ap.add_argument("--description", default=DEFAULT_DESC, help="仓库描述")
    ap.add_argument("--private", action="store_true", help="创建为私有仓库（默认公开）")
    ap.add_argument("--no-create", action="store_true", help="仓库已在网页建好，跳过创建步骤")
    args = ap.parse_args()

    # 切到脚本所在目录（= 项目根目录），保证 git 命令作用在正确的仓库上
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if not token:
        sys.exit("错误：未找到 Token。请先设置环境变量 GITHUB_TOKEN（见文件顶部注释）。")

    # 0) 确认当前目录是 git 仓库
    if not os.path.isdir(".git"):
        sys.exit("错误：当前目录不是 git 仓库。请先执行  git init && git add -A && git commit -m init")

    # 1) 校验 token 并拿到用户名
    try:
        me = api("GET", "/user", token)
    except urllib.error.HTTPError as e:
        sys.exit("错误：Token 无效或已过期（HTTP %s）。" % e.code)
    login = me["login"]
    print("✔ 登录账号：%s" % login)

    # 2) 创建仓库
    if args.no_create:
        print("• 跳过创建（--no-create），直接使用已有仓库 %s/%s" % (login, args.repo))
    else:
        payload = {
            "name": args.repo,
            "description": args.description,
            "private": bool(args.private),
            "has_issues": True,
            "has_wiki": False,
            "auto_init": False,
        }
        try:
            api("POST", "/user/repos", token, payload)
            print("✔ 已创建%s仓库：%s/%s" % ("私有" if args.private else "公开", login, args.repo))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")
            if e.code == 422:
                print("• 仓库已存在，跳过创建。")
            elif e.code == 403:
                sys.exit("错误：创建仓库被拒（403），Token 权限不足。\n"
                         "  经典 Token 请勾选 repo；细粒度 Token 需 Administration: Read and write。\n"
                         "  或者你手动在网页建好仓库后，用 --no-create 重跑。")
            else:
                sys.exit("错误：创建仓库失败 HTTP %s\n%s" % (e.code, body))

    # 3) 关联远端（临时把 token 放进 URL，推送后立刻还原）
    url_with_token = "https://x-access-token:%s@github.com/%s/%s.git" % (token, login, args.repo)
    url_clean = "https://github.com/%s/%s.git" % (login, args.repo)

    remotes = subprocess.run(["git", "remote"], capture_output=True, text=True).stdout.split()
    if "origin" in remotes:
        subprocess.run(["git", "remote", "set-url", "origin", url_with_token], check=True)
    else:
        subprocess.run(["git", "remote", "add", "origin", url_with_token], check=True)

    # 4) 推送
    print("• 开始推送…")
    try:
        git(["branch", "-M", "main"])
        git(["push", "-u", "origin", "main"])
    finally:
        # 无论成功失败，都把带 token 的地址抹掉，避免凭据留在 .git/config
        subprocess.run(["git", "remote", "set-url", "origin", url_clean])

    print("\n完成 ✔ 仓库地址：%s" % url_clean)


if __name__ == "__main__":
    main()
